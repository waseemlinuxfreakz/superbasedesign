import React from 'react'

const Profile = () => {
	return (
		<div>
			profile
		</div>
	)
}

export default Profile
