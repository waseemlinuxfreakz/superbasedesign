import { createClient } from '@supabase/supabase-js';
import { SUPABASE_URL, SUPABASE_API_KEY, EMAILJS_API_KEY, EMAILJS_SERVICE_ID, MAILCHIMP_API_KEY } from '../config.js';
import axios from 'axios';

const supabaseUrl = SUPABASE_URL;
const supabaseKey = SUPABASE_API_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);
const maindataTable = 'maindata';

import emailjs from 'emailjs-com';

// import { Mandrill } from 'mandrill-api';

// const mandrill = new Mandrill(MAILCHIMP_API_KEY);

// Initialize EmailJS with your User ID
emailjs.init(EMAILJS_API_KEY);

const generateSalt = () => {
  const randomBytes = new Uint8Array(16);
  window.crypto.getRandomValues(randomBytes);
  return Array.from(randomBytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
};

const hashPassword = async (password, salt) => {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + salt);
  const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((byte) => byte.toString(16).padStart(2, '0')).join('');
};

const geocodeCity = async (city, state, country) => {
  try {
    const address = `${city}, ${state}, ${country}`;
    const encodedAddress = encodeURIComponent(address);

    const response = await axios.get(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodedAddress}`
    );

    const results = response.data;

    if (results && results.length > 0) {
      const result = results[0];
      const { lat, lon } = result;
      return { latitude: parseFloat(lat), longitude: parseFloat(lon) };
    } else {
      console.log('No results found for the city:', city, state, country);
      return null;
    }
  } catch (error) {
    console.log('Error geocoding:', error);
    return null;
  }
};

  //  // Send a welcome email to the newly registered user
  //  const sendWelcomeEmail = async (userData) => {
  //   // Prepare the welcome email content
  //   const emailContent = `
  //     Dear ${userData.clinicName},
  
  //     Welcome to our platform! Thank you for registering with us.
  
  //     Here are the details you provided:
  //     ${Object.entries(userData)
  //       .filter(([key]) => !['password', 'confirmPassword', 'latitude', 'longitude', 'conditionsSuggestions', 'confirmEmail'].includes(key))
  //       .map(([key, value]) => {
  //         if (key === 'clinicName') {
  //           return `Doctor/Clinic Name: ${value}`;
  //         }
  //         if (key === 'website') {
  //           return value ? `Website: ${value}` : '';
  //         }
  //         return `${key}: ${value}`;
  //       })
  //       .filter((line) => line !== '')
  //       .join('\n')}
  
  //     If you have any questions or need assistance, feel free to contact us.
  
  //     Best regards,
  //     Your Platform Team
  //   `;
  
  //   const message = {
  //     html: emailContent,
  //     subject: 'Welcome to Our Platform!',
  //     from_email: 'ben@regenmedgloba.com',
  //     from_name: 'Your Platform Team',
  //     to: [{ email: userData.email, name: userData.clinicName }],
  //     important: true,
  //     track_opens: true,
  //     track_clicks: true,
  //   };
  
  //   // Send the email using Mandrill API
  //   try {
  //     const result = await mandrill.messages.send({ message });
  //     console.log('Email sent successfully:', result);
  //   } catch (error) {
  //     console.error('Error sending email:', error);
  //     throw new Error('Failed to send welcome email');
  //   }
  // };

const insertNewUser = async (userData) => {
  try {
    const {
      clinicName,
      description,
      conditions,
      treatments,
      address,
      country,
      city,
      state,
      phone,
      email,
      password,
    } = userData;

     // Check if the email is already used in the database
     const { data: existingUser, error: fetchError } = await supabase
     .from(maindataTable)
     .select('email') // Specify the columns you want to retrieve (e.g., 'email')
     .eq('email', email)
     .single();

   if (existingUser) {
     // Email already exists in the database, throw an error
     const error = new Error('Email already in use. Please choose a different email address.');
     error.name = 'EmailExistingError';
     throw error;
   }

    // Generate a random 7-digit number as the id
    const id = Math.floor(Math.random() * 9000000) + 1000000;

    // Generate a random salt for password hashing
    const salt = generateSalt();

    // Hash the password
    const hashedPassword = await hashPassword(password, salt);

    // Geocode the city, state, and country to get the latitude and longitude
    const userCoordinates = await geocodeCity(city, state, country);
    if (!userCoordinates) {
      const error = new Error('Invalid location');
      error.name = 'LocationError';
      throw error;
    }

    // Prepare the data to be inserted, explicitly adding the 'salt' property
    const newData = {
      id: id,
      name: clinicName,
      description: description,
      conditions: conditions,
      treatments: treatments,
      address: address,
      city: city,
      country: country,
      state: state,
      phone: phone,
      email: email,
      password: hashedPassword,
      password_salt: salt, // Use the correct column name 'password_Salt
      latitude: userCoordinates.latitude,
      longitude: userCoordinates.longitude,
      created_at: new Date().toISOString(),
    };

    // Insert data into the "maindata" table using Supabase
    const { data, error } = await supabase.from(maindataTable).insert([newData]);

    if (error) {
      throw new Error('Failed to insert data');
    }

    console.log('Data inserted successfully:', data);

     


    return { message: 'Data inserted successfully' };
  } catch (error) {
    console.error('Error inserting data:', error);
    throw error; // Throw the specific error from insertNewUser
  }
};


export default insertNewUser;
